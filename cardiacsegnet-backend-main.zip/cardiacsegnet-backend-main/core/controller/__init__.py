from .base import BaseController

__all__ = ["BaseController"]
