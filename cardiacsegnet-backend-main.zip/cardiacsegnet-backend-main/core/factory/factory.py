from functools import partial

from fastapi import Depends

from app.controllers import UserController, AuthController, ImagesController
from app.models import User
from app.repositories import UserRepository, ImagesRepository

from core.database import get_session



class Factory:
    """
    This is the factory container that will instantiate all the controllers and
    repositories which can be accessed by the rest of the application.
    """

    # Repositories
    # user_repository = partial(UserRepository, User)

    def get_user_controller(self, db_session=Depends(get_session)):
        return UserController(
            # user_repository=self.user_repository(db_session=db_session)
            user_repository = UserRepository()
        )

    def get_auth_controller(self, db_session=Depends(get_session)):
        return AuthController(
            # user_repository=self.user_repository(db_session=db_session),
            user_repository = UserRepository()
        )

    def get_images_controller(self, db_session=Depends(get_session)):
        return ImagesController(
            images_repository = ImagesRepository()
        )