from .image_module import save_slice_as_image

__all__ = [
save_slice_as_image
]
